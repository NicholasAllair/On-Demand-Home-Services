package com.example.eleanor.segproject;

public class RateProvider {
}
